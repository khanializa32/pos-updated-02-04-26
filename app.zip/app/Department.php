<?php

namespace App;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Department extends Model
{
    use HasFactory;

    protected $fillable = [
        'country_id', 'name', 'code',
    ];

    protected $hidden = [
        'country_id',
    ];
}
